package execucao;

import java.util.ArrayList;
import java.util.Scanner;

import entidade.Colaborador;

public class Principal {

	public static void main(String[] args) {
		Scanner ent = new Scanner(System.in);
		String nome, matricula, sSalario; 
		double salario;
		ArrayList<Colaborador> listaColab = new ArrayList<Colaborador>();
		// Entrando os dados
		for (int x = 0; x < 2; x++) {
			System.out.println("\n"+(x+1)+"o. Colaborador");
			System.out.print("Nome:");
			nome = ent.nextLine();
			System.out.print("Matricula:");
			matricula = ent.nextLine();
			System.out.print("Salario(R$):");
			// lembrando que a quest�o diz que s� pode entrar dados com nextLine()
			sSalario = ent.nextLine(); 
			// convertendo String para double - ver slides da aula passada que mostra classes e fun��es para convers�o
			salario = Double.parseDouble(sSalario); 
			listaColab.add(new Colaborador(nome, matricula, salario));
		}
		// Processando o aumento salarial
		for (Colaborador obj : listaColab) {
			obj.aumentarSalario();
		}
		// Exibe novo sal�rio com as info. solicitadas
		System.out.println("Listagem Atualizada (com aumento salarial):");
		for(Colaborador obj : listaColab) {
			String msg = // lembrando que nome s� � a 1a letra 
						"Nome:" + obj.getNome().substring(0, 1)  
						+ ", Matricula:" + obj.getMatricula()
						// formatando sal�rio, para ficar mais apresent�vel, sempre com duas casas decimais e ponto de milhar
						+ ", Salario(R$):" + String.format("%,.2f", obj.getSalario()); 
			System.out.println(msg);
		}
		ent.close();

	}
	
	
}
