package entidade;

public class Colaborador {
	
	private String nome;
	private String matricula;
	private double salario;
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public Colaborador(String nome, String matricula, double salario) {
		this.nome = nome;
		this.matricula = matricula;
		this.salario = salario;
		
	}
	
	public void aumentarSalario() {
		this.salario *= 1.05;
	}
}
